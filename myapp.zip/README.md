# EduStream Server
### Name subject to change

Server to run EduStream, the integrated classroom streaming service.

Currently in initial development.
